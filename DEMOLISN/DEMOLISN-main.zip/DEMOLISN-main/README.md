# demolisn
visjak vytvorime legendarni hru o bejrovi 100% validni
Uvaril stepi jerab cednik honzabenedikt a viktor
